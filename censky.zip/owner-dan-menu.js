const fs = require('fs')

global.namabot = "CenBot"
global.namaowner = "Censky"
global.footer_text = "©Censky_store " + namabot
global.pp_bot = fs.readFileSync("./image/yaya.jpg")
global.qris = fs.readFileSync("./image/qris.jpg")
global.owner = ['6281915659799']
global.sessionName = 'session'
global.prefa = ['-_-']
global.caption_pay = `Qris All Pay
Ovo
Dana

Mau ganti payment? ketik .setpay
`
//menu bot rapihin sendiri ya, belajar lah jadi anak mandiri.
module.exports.helpMenu = (pushname) =>{
  return `Halo ${pushname}

𝚂𝚊𝚢𝚊 𝚊𝚍𝚊𝚕𝚊𝚑 *${global.namabot}*,

sɪʟᴀᴋᴀɴ ɢᴜɴᴀᴋᴀɴ ᴘᴇʀɪɴᴛᴀʜ ʏᴀɴɢ ᴛᴇʀsᴇᴅɪᴀ. ᴊɪᴋᴀ ʙᴜᴛᴜʜ ʙᴀɴᴛᴜᴀɴ, ʜᴜʙᴜɴɢɪ ᴏᴡɴᴇʀ.

${global.footer_text}


*「 FITUR BOT 」*

\`\`\`
┌──⭓ 𝘚𝘛𝘖𝘙𝘌 ⭓──
│⎚ » 𝘭𝘪𝘴𝘵
│⎚ » 𝘢𝘥𝘥𝘭𝘪𝘴𝘵
│⎚ » 𝘶𝘱𝘥𝘢𝘵𝘦𝘭𝘪𝘴𝘵
│⎚ » 𝘳𝘦𝘯𝘢𝘮𝘦𝘭𝘪𝘴𝘵
│⎚ » 𝘥𝘦𝘭𝘭𝘪𝘴𝘵
│⎚ » 𝘴𝘦𝘵𝘱𝘳𝘰𝘴𝘦𝘴
│⎚ » 𝘤𝘩𝘢𝘯𝘨𝘦𝘱𝘳𝘰𝘴𝘦𝘴
│⎚ » 𝘥𝘦𝘭𝘴𝘦𝘵𝘱𝘳𝘰𝘴𝘦𝘴
│⎚ » 𝘴𝘦𝘵𝘥𝘰𝘯𝘦
│⎚ » 𝘤𝘩𝘢𝘯𝘨𝘦𝘥𝘰𝘯𝘦
│⎚ » 𝘥𝘦𝘭𝘴𝘦𝘵𝘥𝘰𝘯𝘦
│⎚ » 𝘱𝘳𝘰𝘴𝘦𝘴
│⎚ » 𝘥𝘰𝘯𝘦
└───────⭓

┌──⭓ 𝘖𝘞𝘕𝘌𝘙 ⭓──
│⎚ » 𝘢𝘥𝘥𝘴𝘦𝘸𝘢
│⎚ » 𝘥𝘦𝘭𝘴𝘦𝘸𝘢
│⎚ » 𝘭𝘪𝘴𝘵𝘴𝘦𝘸𝘢
└───────⭓

┌──⭓ 𝘈𝘋𝘔𝘐𝘕 ⭓──
│⎚ » 𝘤𝘦𝘬𝘴𝘦𝘸𝘢
│⎚ » 𝘸𝘦𝘭𝘤𝘰𝘮𝘦
│⎚ » 𝘨𝘰𝘰𝘥𝘣𝘺𝘦
│⎚ » 𝘴𝘦𝘵𝘸𝘦𝘭𝘤𝘰𝘮𝘦
│⎚ » 𝘤𝘩𝘢𝘯𝘨𝘦𝘸𝘦𝘭𝘤𝘰𝘮𝘦
│⎚ » 𝘥𝘦𝘭𝘴𝘦𝘵𝘸𝘦𝘭𝘤𝘰𝘮𝘦
│⎚ » 𝘴𝘦𝘵𝘭𝘦𝘧𝘵
│⎚ » 𝘤𝘩𝘢𝘯𝘨𝘦𝘭𝘦𝘧𝘵
│⎚ » 𝘥𝘦𝘭𝘴𝘦𝘵𝘭𝘦𝘧𝘵
│⎚ » 𝘢𝘯𝘵𝘪𝘸𝘢𝘮𝘦
│⎚ » 𝘢𝘯𝘵𝘪𝘸𝘢𝘮𝘦2
│⎚ » 𝘢𝘯𝘵𝘪𝘭𝘪𝘯𝘬
│⎚ » 𝘢𝘯𝘵𝘪𝘭𝘪𝘯𝘬2
│⎚ » 𝘰𝘱𝘦𝘯
│⎚ » 𝘤𝘭𝘰𝘴𝘦
│⎚ » 𝘩𝘪𝘥𝘦𝘵𝘢𝘨
│⎚ » 𝘢𝘥𝘥
│⎚ » 𝘬𝘪𝘤𝘬
│⎚ » 𝘴𝘵𝘪𝘬𝘦𝘳
│⎚ » 𝘧𝘧𝘪𝘥
│⎚ » 𝘮𝘭𝘪𝘥
│⎚ » 𝘴𝘦𝘵𝘱𝘱𝘨𝘤
│⎚ » 𝘴𝘦𝘵𝘯𝘢𝘮𝘦𝘨𝘤
│⎚ » 𝘴𝘦𝘵𝘥𝘦𝘴𝘨𝘤
│⎚ » 𝘭𝘪𝘯𝘬𝘨𝘤
│⎚ » 𝘳𝘦𝘴𝘦𝘵𝘭𝘪𝘯𝘬𝘨𝘤
│⎚ » 𝘱𝘳𝘰𝘮𝘰𝘵𝘦
│⎚ » 𝘥𝘦𝘮𝘰𝘵𝘦
│⎚ » 𝘴𝘦𝘵𝘣𝘰𝘵
│⎚ » 𝘶𝘱𝘥𝘢𝘵𝘦𝘴𝘦𝘵𝘣𝘰𝘵
│⎚ » 𝘥𝘦𝘭𝘴𝘦𝘵𝘣𝘰𝘵
└───────⭓
\`\`\`

📝 *NOTE*: 
𝗜𝗻𝗴𝗶𝗻 𝗺𝗲𝗻𝘆𝗲𝘄𝗮 𝗕𝗼𝘁 𝗶𝗻𝗶? 𝗦𝗶𝗹𝗮𝗸𝗮𝗻 𝗞𝗲𝘁𝗶𝗸 .𝗼𝘄𝗻𝗲𝗿
𝗛𝗮𝗿𝗴𝗮 𝗠𝘂𝗿𝗮𝗵 𝗖𝗼𝗰𝗼𝗸 𝗨𝗻𝘁𝘂𝗸 𝗚𝗿𝘂𝗽 𝗦𝘁𝗼𝗿𝗲 𝗞𝗮𝗺𝘂.
𝗕𝗼𝘁 𝗔𝗸𝘁𝗶𝗳 𝟮𝟰 𝗝𝗮𝗺!!!
`
}